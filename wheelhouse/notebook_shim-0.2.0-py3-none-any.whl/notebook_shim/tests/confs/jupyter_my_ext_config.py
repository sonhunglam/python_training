c.MyExt.hello = 'My extension'
