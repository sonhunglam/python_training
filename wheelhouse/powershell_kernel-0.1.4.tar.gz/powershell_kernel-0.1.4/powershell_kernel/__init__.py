"""A powershell kernel for Jupyter"""
__version__ = '0.1.4'
