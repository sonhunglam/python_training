from ._version import version_info, __version__
